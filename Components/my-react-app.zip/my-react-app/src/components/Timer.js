import React from 'react';
//import {useState} from 'react'

const Timer = (props) => {
    //props is immutable which means we cannot change it and force the seconds++
    //let seconds = props.start;

    const [seconds, setSeconds] = React.useState(props.start);
    // the param x in useState(x) is the number from which the counting will start

    //Not a good practice --> useEffect is better!
    setTimeout(() => {
        //setSeconds(seconds + 1); --> we use this if we want to set a certain value
        //to change the seconds we MUST use the useState function, in this case called setSeconds
        setSeconds(oldSeconds => oldSeconds + 1);
        //the setter function guarantees correct updating of the number
        //we use the setter func if we want to set new value ACCORDING to the previos value 
    }, 1000);
    //setTimeoute() goes straight to the queue and waits for her turn, meanwhile the div from the next line will be rendered 

    return (
        <div>
            <h2>Timer</h2>
            Time: {seconds}s
        </div>
    );
};

export default Timer;