import { useState } from 'react';

const getTitle = (count) => {
    switch (count) {
        case 1: return 'First Blood';
        case 2: return 'Double Kill';
        case 3: return 'Triple Kill';
        case 4: return 'Multi Kill';
        case 5: return 'Unstoppable';
        default: return 'Counter';
    }
};

const Counter = (props) => {
    const [counter, setCounter] = useState(0);

    const onIncrementCounter = (e) => {
        setCounter(oldCounter => oldCounter + 1);
    };
    const onDecrementCounter = (e) => {
        setCounter(oldCounter => oldCounter - 1);
    };
    const onClearCounter = (e) => {
        setCounter(0);
    };

    // let title = 'Counter';
    // if (counter === 1) {
    //     title = "First Blood";
    // } else if (counter === 2) {
    //     title = 'Double Kill';
    // }
    return (
        <div>
            {/* Math.max(counter,1) --> if the counter is 0 or -1 it will be 1 */}
            <p style={{ fontSize: Math.max(counter, 1) + 'em' }}>
                {counter > 5 ? 'Godlike' : getTitle(counter)}: {counter}</p>
            <button onClick={onDecrementCounter}>-</button>
            {/* Very interesting syntax: if the left part of the ternary is true it will return the right part
                if the left is false it won't return the button */}
            {props.isResettable && <button onClick={onClearCounter}>Clear</button>}
            {counter < 10
                ? <button onClick={onIncrementCounter}>+</button>
                : null
            }
            {/* hides button if count>=10 */}
        </div>
    );
};
export default Counter;