import './App.css';
import MovieList from './components/MovieList.js';
import Timer from './components/Timer.js';
import Counter from './components/Counter.js';

function App() {
    const movies = [
        { title: 'Man of Steel', year: 2005, cast: ["Henry Cavil", "Russell Crowe"] },
        { title: 'Harry Potter', year: 2008, cast: ["Daniel Radcliff", "Emma Watson"] },
        { title: 'Bad Boys', year: 1999, cast: ["Will Smith"] },
    ];


    return (
        <div className="App">
            <h1>React Demo</h1>
            <Counter isResettable />
            <Timer start={0} />
            {/* we pass the number 5 in {} */}
            {/* <Timer start={15} /> */}
            {/* <Timer start={35} /> */}
            <MovieList movies={movies} />
            {/* we use props here */}

        </div>
    );
}

export default App;
